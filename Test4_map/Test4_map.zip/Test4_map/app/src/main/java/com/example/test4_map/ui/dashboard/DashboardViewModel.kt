package com.example.test4_map.ui.dashboard

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DashboardViewModel : ViewModel() {
/*
    private val _text = MutableLiveData<String>().apply {
        value = "This is Maps Fragment"
    }
    val text: LiveData<String> = _text
    */
}