package com.example.test4_map

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
open class toSave (
    @PrimaryKey var id:String  = "",
            var data1:String = "",
            var data2:String = "",
            var data3:String = "",
            var data4:String = "",
            var data5:String = ""
) : RealmObject() { }