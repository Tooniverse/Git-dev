package com.example.test4_map.ui.dashboard

import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment

import android.os.Bundle
import org.jetbrains.anko.*
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.Nullable
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.fragment.navArgs
import com.example.test4_map.MainActivity
import com.example.test4_map.MarkerItem
import com.example.test4_map.R
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.fragment_dashboard.*
import org.jetbrains.anko.custom.style

class DashboardFragment : Fragment(),OnMapReadyCallback {

    private lateinit var dashboardViewModel: DashboardViewModel
    private lateinit var mMap: MapView

    var val_gps: String? = ""
    var gps_List: MutableList<MarkerItem> = mutableListOf(
        MarkerItem("0", 0.0, 0.0, "time"), MarkerItem("1", 0.0, 0.0, "time"),
        MarkerItem("2", 0.0, 0.0, "time"), MarkerItem("3", 0.0, 0.0, "time"),
        MarkerItem("4", 0.0, 0.0, "time"), MarkerItem("5", 0.0, 0.0, "time")
    )

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        dashboardViewModel =
            ViewModelProviders.of(this).get(DashboardViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_dashboard, container, false)



        return root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //mMap = view.findViewById(R.id.mapView)
        //mMap.onCreate(savedInstanceState)

        mapView.onCreate(savedInstanceState)
        val_gps = arguments?.getString("navGPS") //?: "0/0.0/0.0/time!1/0.0/0.0/time!2/0.0/0.0/time!3/0.0/0.0/time!4/0.0/0.0/time!"
        mMap = view.findViewById(R.id.mapView) as MapView
        mMap.getMapAsync(this)

    }

    override fun onResume() {
        super.onResume()
        mMap.onResume()
    }

    override fun onPause() {
        super.onPause()
        mMap.onPause()
    }

    override fun onStart() {
        super.onStart()
        mMap.onStart()
    }

    override fun onStop() {
        super.onStop()
        mMap.onStop()
    }

    override fun onDestroy() {
        super.onDestroy()
        mMap.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mMap.onLowMemory()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mMap.onSaveInstanceState(outState)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        var tmp = val_gps?.trim()
        var ss = tmp?.split("!")
        //Toast.makeText(getActivity(), ss?.size.toString(), Toast.LENGTH_LONG).show()
        //Toast.makeText(getActivity(), tmp, Toast.LENGTH_LONG).show()
        //Toast.makeText(getActivity(), ss!![1].toString(), Toast.LENGTH_LONG).show()
        if (ss!!.size > 2) {
            for (item: Int in 0..5) {
                var sss = ss[item].split("/")
                //Toast.makeText(getActivity(), sss.size.toString(), Toast.LENGTH_LONG).show()
                if (sss.isNotEmpty()) {
                        gps_List[item].m_num = sss[0]
                        gps_List[item].lat = sss[1].toDouble()
                        gps_List[item].lon = sss[2].toDouble()
                        gps_List[item].recieve_time = sss[3]
                    }

                //Toast.makeText(getActivity(), gps_List[0].lat.toString(), Toast.LENGTH_LONG).show()

                if(gps_List[item].lat != 0.0) {
                    val makeMark = LatLng(gps_List[item].lat, gps_List[item].lon)

                    val markerOptions = MarkerOptions()

                    markerOptions.position(makeMark)

                    markerOptions.title(gps_List[item].m_num.toString())

                    markerOptions.snippet(gps_List[item].recieve_time)

                    googleMap.addMarker(markerOptions)

                    googleMap.moveCamera(CameraUpdateFactory.newLatLng(makeMark))

                    googleMap.animateCamera(CameraUpdateFactory.zoomTo(18f))
                    /*
                val SEOUL = LatLng(37.02, 128.3)


                val markerOptions = MarkerOptions()

                markerOptions.position(SEOUL)

                markerOptions.title("서울")

                markerOptions.snippet("수도")

                googleMap.addMarker(markerOptions)

                googleMap.moveCamera(CameraUpdateFactory.newLatLng(SEOUL))

                googleMap.animateCamera(CameraUpdateFactory.zoomTo(18f))

                 */
                }
            }

        }

    }
}